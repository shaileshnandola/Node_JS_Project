const express = require('express');

const routes = express.Router();

const categoryctr = require("../controllers/categoryCtr")
const AddCategory = require('../models/categorymodel');

routes.get("/addCategory",categoryctr.addCategory)

module.exports = routes;