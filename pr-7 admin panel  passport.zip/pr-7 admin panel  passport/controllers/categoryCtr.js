// const AddCategory = require('../models/categorymodel');


module.exports.addCategory = async (req, res) => {
    try {
        return res.render("category/addCategory")
    }
    catch (err) {
        console.log(err);
        return res.redirect("/")
    }
}